// weapon_audio.js - phát âm thanh vũ khí trong game HTML5 (Web Audio API, không cần thư viện)
// Cấu trúc:  weapons/<vũ khí>/<sự kiện>_<n>.wav   (giải nén weapon_audio.zip)
// LƯU Ý: chạy qua server cục bộ (python3 -m http.server) vì trình duyệt chặn fetch trên file://,
//        và chỉ tạo WeaponAudio sau cú click/phím đầu tiên của người chơi (chính sách autoplay).
//
// Ví dụ:
//   const wa = new WeaponAudio();
//   await wa.load(["pistol", "uzi", "shotgun", "grenade", "rocket", "railgun"]);
//   wa.play("pistol", "fire");                                       // bắn (tự đổi biến thể, không lặp liền nhau)
//   const auto = wa.startAuto("uzi", 13);  ...  auto.stop();          // bắn liên thanh 13 viên/giây
//   wa.play("shotgun", "pump");                                      // lên đạn sau mỗi phát
//   wa.play("grenade", "explode", { x: g.x, y: g.y, listenerX: player.x, listenerY: player.y, maxDist: 1200 });
//   const motor = wa.loop("rocket", "flight", pos);                  // tiếng rocket bay (lặp liền mạch)
//   motor.update({ x: rk.x, y: rk.y, listenerX: player.x, listenerY: player.y });  motor.stop();
//   wa.play("railgun", "charge");  ...  wa.play("railgun", "fire");  wa.play("railgun", "cooldown");

const WEAPON_SFX = {
  pistol:  { fire: 3, reload: 1, empty: 1, casing: 2 },
  uzi:     { fire: 4, reload: 1, empty: 1, casing: 2 },
  shotgun: { fire: 3, pump: 2, load: 2, empty: 1, casing: 2 },
  grenade: { pin: 1, throw: 1, bounce: 3, explode: 2 },
  rocket:  { load: 1, fire: 2, flight: 1, explode: 2 },
  railgun: { charge: 1, fire: 3, cooldown: 1, empty: 1, impact: 2 },
};
const WEAPON_SFX_VOL = { fire: 1, explode: 1, reload: .6, empty: .5, casing: .35, pump: .75, load: .6,
  pin: .6, throw: .7, bounce: .7, flight: .55, charge: .8, cooldown: .6, impact: .8 };

class WeaponAudio {
  constructor(maxVoices = 32) {
    this.ctx = new (window.AudioContext || window.webkitAudioContext)();
    this.master = this.ctx.createGain();
    this.master.connect(this.ctx.destination);
    this.buf = {};
    this.last = {};
    this.voices = 0;
    this.maxVoices = maxVoices;
  }

  async load(weapons, folder = "weapons/") {
    for (const w of weapons) {
      for (const [ev, n] of Object.entries(WEAPON_SFX[w])) {
        for (let i = 1; i <= n; i++) {
          const res = await fetch(`${folder}${w}/${ev}_${i}.wav`);
          if (!res.ok) throw new Error(`Không tải được ${w}/${ev}_${i}.wav`);
          const audio = await this.ctx.decodeAudioData(await res.arrayBuffer());
          (this.buf[`${w}/${ev}`] ||= []).push(audio);
        }
      }
    }
  }

  _pick(key) {                                     // chọn ngẫu nhiên, không lặp lại biến thể vừa phát
    const list = this.buf[key];
    if (!list) return null;
    if (list.length === 1) return list[0];
    let i;
    do { i = Math.floor(Math.random() * list.length); } while (i === this.last[key]);
    this.last[key] = i;
    return list[i];
  }

  _spatial(o) {                                    // xa thì nhỏ + bị "bịt" tiếng cao, lệch trái/phải thì pan
    if (o.x === undefined) return { k: 1, pan: 0, cut: 20000 };
    const dx = o.x - (o.listenerX ?? 0), dy = (o.y ?? 0) - (o.listenerY ?? 0);
    const md = o.maxDist ?? 900;
    const k = Math.max(0, 1 - Math.hypot(dx, dy) / md);
    return { k, pan: Math.max(-1, Math.min(1, dx / md * 1.5)), cut: 800 + 19000 * k * k };
  }

  _wire(src, vol, s) {
    const lp = this.ctx.createBiquadFilter();
    lp.type = "lowpass"; lp.frequency.value = s.cut;
    const g = this.ctx.createGain(); g.gain.value = vol;
    const p = this.ctx.createStereoPanner(); p.pan.value = s.pan;
    src.connect(lp).connect(g).connect(p).connect(this.master);
    return { lp, g, p };
  }

  // o: { x, y, listenerX, listenerY, maxDist, volume, pitch, delay }
  play(weapon, ev, o = {}) {
    const buf = this._pick(`${weapon}/${ev}`);
    if (!buf || this.voices >= this.maxVoices) return null;
    if (this.ctx.state === "suspended") this.ctx.resume();
    const s = this._spatial(o);
    const vol = (WEAPON_SFX_VOL[ev] ?? 1) * (o.volume ?? 1) * s.k;
    if (vol < 0.01) return null;
    const src = this.ctx.createBufferSource();
    src.buffer = buf;
    src.playbackRate.value = (o.pitch ?? 1) * (0.97 + Math.random() * 0.06);
    this._wire(src, vol, s);
    this.voices++;
    src.onended = () => this.voices--;
    src.start(this.ctx.currentTime + (o.delay ?? 0));
    return src;
  }

  loop(weapon, ev, o = {}) {                       // âm lặp, ví dụ rocket đang bay
    const buf = this._pick(`${weapon}/${ev}`);
    if (!buf) return null;
    if (this.ctx.state === "suspended") this.ctx.resume();
    const src = this.ctx.createBufferSource();
    src.buffer = buf; src.loop = true;
    const base = (WEAPON_SFX_VOL[ev] ?? 1) * (o.volume ?? 1);
    const s = this._spatial(o);
    const n = this._wire(src, base * s.k, s);
    src.start();
    return {
      update: (q) => {                             // gọi mỗi frame khi nguồn âm hoặc người nghe di chuyển
        const t = this._spatial({ ...o, ...q });
        n.g.gain.value = base * t.k; n.p.pan.value = t.pan; n.lp.frequency.value = t.cut;
      },
      stop: (fade = 0.1) => {
        n.g.gain.setTargetAtTime(0, this.ctx.currentTime, fade / 3);
        src.stop(this.ctx.currentTime + fade + 0.05);
      },
    };
  }

  startAuto(weapon, shotsPerSec, getPos = () => ({})) {   // bắn liên thanh
    const id = setInterval(() => this.play(weapon, "fire", getPos()), 1000 / shotsPerSec);
    return { stop: () => clearInterval(id) };
  }
}
