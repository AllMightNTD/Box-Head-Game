"""Tổng hợp âm thanh 6 vũ khí bằng DSP thuần: pistol, uzi, shotgun, grenade, rocket, railgun.
Chạy:  python3 weapon_audio_generator.py   ->  weapons/<vũ khí>/<sự kiện>_<n>.wav
Cần: numpy, scipy (matplotlib nếu muốn ảnh phổ). Thư mục xuất: biến môi trường ZOMBIE_OUT (mặc định ".")."""
import numpy as np, os, json, wave, zlib, zipfile, warnings
from scipy import signal

warnings.filterwarnings("ignore")
SR = 44100
OUT_DIR = os.environ.get("ZOMBIE_OUT", ".")


# ------------------------------------------------------------ tiện ích cơ bản
def n_of(d): return int(SR * d)
def tt(d): return np.arange(n_of(d)) / SR
def newbuf(d): return np.zeros(n_of(d))
def noise(d, r): return r.standard_normal(n_of(d))
def lp(x, f, order=2): return signal.sosfilt(signal.butter(order, f, "low", fs=SR, output="sos"), x)
def bp(x, lo, hi, order=2): return signal.sosfilt(signal.butter(order, [lo, hi], "band", fs=SR, output="sos"), x)


def curve(d, pts):
    xs, ys = zip(*pts)
    return np.interp(tt(d), xs, ys)


def smooth_noise(d, rate, r):
    n = n_of(d)
    k = max(2, int(SR / rate))
    pts = r.standard_normal(n // k + 3)
    return np.interp(np.arange(n) / k, np.arange(len(pts)), pts)


def place(out, sig, t0, g=1.0):
    i = int(t0 * SR)
    if i >= len(out):
        return
    f = min(len(sig), int(SR * .004))
    sig = sig.copy()
    sig[-f:] *= np.linspace(1, 0, f)                # tắt dần 4ms, tránh tiếng tách do cắt cụt
    j = min(len(out), i + len(sig))
    out[i:j] += g * sig[:j - i]


def burst(d, lo, hi, r, decay=20, attack=0.002):
    t = tt(d)
    return bp(noise(d, r), lo, hi) * np.minimum(t / attack, 1) * np.exp(-t * decay)


def whoosh(d, lo, hi, r):
    return bp(noise(d, r), lo, hi) * np.sin(np.pi * tt(d) / d) ** 2


def thud(d, f0, f1, decay, click, r):
    t = tt(d)
    f = f1 + (f0 - f1) * np.exp(-t * 30)
    y = np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t * decay)
    return y + click * lp(noise(d, r), 1500) * np.exp(-t * 120)


def crackles(d, density, lo, hi, r, decay=0.0):
    n = n_of(d)
    y = np.zeros(n)
    k = r.poisson(density * d)
    if k:
        y[r.integers(0, n - 200, size=k)] = r.uniform(.3, 1, size=k) * r.choice([-1, 1], size=k)
    y = bp(y, lo, hi)
    b, a = signal.iirpeak(r.uniform(lo, hi) / (SR / 2), 3)
    return signal.lfilter(b, a, y) * np.exp(-tt(d) * decay)


def clink(base, d=.8):
    t = tt(d)
    y = sum(g * np.sin(2 * np.pi * base * m * t) * np.exp(-t * dec)
            for m, g, dec in ((1, 1, 6), (2.76, .6, 9), (5.4, .4, 14), (8.93, .25, 20)))
    return y * np.minimum(t / .001, 1)


def sweep(d, f0, f1, kind="sine"):
    t = tt(d)
    ph = np.cumsum(f0 * (f1 / f0) ** (t / d)) / SR
    return np.sin(2 * np.pi * ph) if kind == "sine" else 2 * (ph % 1) - 1


def reverb(x, rt60, wet, r, lpf=5000):
    """vang phòng: nhân chập với nhiễu suy giảm mũ"""
    ir = lp(r.standard_normal(n_of(rt60)), lpf) * np.exp(-tt(rt60) * 6.9 / rt60)
    ir[:int(SR * .004)] = 0
    y = signal.fftconvolve(x, ir)[:len(x)]
    return x + wet * y / (np.max(np.abs(y)) + 1e-9) * np.max(np.abs(x))


# ------------------------------------------------------------ cơ khí
def tick(r, f=3500, d=.03):                         # tiếng "tách" kim loại
    t = tt(d)
    return burst(d, 1500, 9000, r, decay=250, attack=.0004) * .8 + .5 * np.sin(2 * np.pi * f * t) * np.exp(-t * 160)

def clack(r, f=900, d=.09):                         # tiếng "cạch" nặng
    t = tt(d)
    return burst(d, 400, 5000, r, decay=70, attack=.0005) + .7 * np.sin(2 * np.pi * f * t) * np.exp(-t * 60)

def scrape(r, d, lo=1500, hi=6000):                 # kim loại ma sát trượt
    t = tt(d)
    return bp(noise(d, r), lo, hi) * np.sin(np.pi * t / d) ** .7 * (.7 + .3 * np.sign(np.sin(2 * np.pi * 95 * t)))

def casing(r, f, dur, bounces, decay):              # vỏ đạn nảy lách cách
    out = newbuf(dur)
    t0, amp, gap = 0., 1., .11
    t = np.arange(int(SR * .12)) / SR
    for _ in range(bounces):
        s = (np.sin(2 * np.pi * f * t) + .6 * np.sin(2 * np.pi * f * 1.52 * t) + .35 * np.sin(2 * np.pi * f * 2.31 * t))
        place(out, s * np.exp(-t * decay) * np.minimum(t / .0005, 1), t0, amp)
        t0 += gap
        gap *= r.uniform(.55, .7)
        amp *= r.uniform(.45, .6)
    return out


# ------------------------------------------------------------ tiếng nổ súng: crack + thân + bụp trầm + vang
def gunshot(r, dur, crack_lo, body, body_decay, thump, thump_decay, tail_rt, tail_wet,
            thump_gain=1.0, crack_gain=1.0, body_gain=1.0, pellets=1, drive=1.2):
    out = newbuf(dur)
    for k in range(pellets):                        # shotgun: nhiều viên đạn nổ lệch vài ms
        t0 = 0 if k == 0 else r.uniform(.0005, .006)
        place(out, burst(.012, crack_lo, 16000, r, decay=500, attack=.0003), t0, crack_gain / np.sqrt(pellets))
    place(out, burst(.4, body[0], body[1], r, decay=body_decay, attack=.0008), 0, body_gain)
    place(out, thud(min(dur, .9), thump[0], thump[1], thump_decay, 0, r), 0, thump_gain)
    return np.tanh(reverb(out, tail_rt, tail_wet, r) * drive)


# ------------------------------------------------------------ tiếng nổ lớn (lựu đạn, rocket)
def explosion(r, dur, boom, boom_dec, rum_dec, debris, roar, rt):
    out = newbuf(dur)
    place(out, burst(.02, 800, 16000, r, decay=300, attack=.0003), 0, 1.0)           # tiếng nổ chói đầu
    place(out, burst(.7, 50, 4000, r, decay=6, attack=.001), 0, 1.2)                 # quả cầu lửa
    place(out, thud(dur, boom[0], boom[1], boom_dec, 0, r), 0, 1.8)        # bụp siêu trầm
    place(out, lp(noise(dur, r), 220) * np.exp(-tt(dur) * rum_dec), .02, 1.3)        # ầm vang
    if roar:
        place(out, lp(noise(1.2, r), 1500) * curve(1.2, [(0, 0), (.12, 1), (1.2, 0)]), .05, roar)
    place(out, crackles(dur - .3, debris, 300, 5000, r, decay=1.2), .3, .8)          # mảnh vụn rơi
    return np.tanh(reverb(out, rt, .5, r, 3000) * 1.1)


# ============================================================ 1. PISTOL: gọn, khô, chắc
def pistol_fire(r, p, i):
    j = r.uniform(.9, 1.1)
    return gunshot(r, .9, 2500, (350 * j, 3800), 38 * j, (190 * p, 75), 45, .45, .45, thump_gain=.9)

def pistol_reload(r, p, i):
    out = newbuf(2.0)
    place(out, clack(r, 700, .06), 0, .8)                                   # nhả băng đạn
    place(out, scrape(r, .16, 1200, 5000), .12, .6)                         # băng trượt ra
    place(out, thud(.12, 200, 90, 40, .2, r), .32, .5)
    place(out, scrape(r, .12, 1200, 5000), .85, .6)                         # băng mới vào
    place(out, clack(r, 450, .09), .97, 1.0); place(out, tick(r, 2800), .97, .5)
    place(out, scrape(r, .2, 900, 4500), 1.35, .8); place(out, tick(r, 2600), 1.53, .7)   # kéo thanh trượt
    place(out, scrape(r, .08, 1200, 5000), 1.62, .5); place(out, clack(r, 800, .1), 1.66, 1.0)  # nhả về
    return out

def pistol_empty(r, p, i):
    out = newbuf(.15)
    place(out, tick(r, 2400, .04), 0, .8); place(out, clack(r, 500, .05), 0, .5)
    return out

def pistol_casing(r, p, i): return casing(r, 3300 * p, .6, 4, 60)


# ============================================================ 2. UZI: giòn, nhanh, lách tách (phát lặp để bắn liên thanh)
def uzi_fire(r, p, i):
    j = r.uniform(.92, 1.08)
    x = gunshot(r, .4, 3000, (500 * j, 5500), 55 * j, (220 * p, 100), 70, .25, .35, thump_gain=.6, drive=1.3)
    place(x, tick(r, 2400 * j, .03), .03, .3)                               # bolt đập
    return x

def uzi_reload(r, p, i):
    out = newbuf(2.3)
    place(out, clack(r, 750, .06), 0, .9)
    place(out, scrape(r, .18, 1200, 5000), .1, .6)
    place(out, scrape(r, .12, 1200, 5000), 1.0, .6); place(out, clack(r, 480, .09), 1.12, 1.0)
    place(out, scrape(r, .28, 700, 4000), 1.55, .9); place(out, clack(r, 500, .1), 1.83, .8)   # kéo bolt
    place(out, clack(r, 650, .1), 2.0, 1.1); place(out, tick(r, 2700), 2.02, .6)
    return out

def uzi_empty(r, p, i):
    out = newbuf(.15)
    place(out, tick(r, 2800, .04), 0, .8); place(out, clack(r, 650, .05), 0, .4)
    return out

def uzi_casing(r, p, i): return casing(r, 3800 * p, .6, 4, 80)


# ============================================================ 3. SHOTGUN: nổ rền, bụp sâu, nhiều đạn chì
def shotgun_fire(r, p, i):
    j = r.uniform(.9, 1.1)
    return gunshot(r, 1.9, 1500, (120 * j, 2600), 16 * j, (130 * p, 38), 14, 1.3, .6,
                   thump_gain=1.6, body_gain=1.3, pellets=5, drive=1.6)

def shotgun_pump(r, p, i):                          # "ch-chk"
    j = r.uniform(-.02, .02)
    out = newbuf(.8)
    place(out, scrape(r, .17, 600, 3500), 0, .8); place(out, clack(r, 420, .1), .17 + j, 1.0)
    place(out, scrape(r, .12, 700, 3800), .42, .7)
    place(out, clack(r, 300, .12), .55 + j, 1.2); place(out, tick(r, 2300), .57 + j, .6)
    return out

def shotgun_load(r, p, i):                          # nhét một viên vào
    j = r.uniform(.9, 1.1)
    out = newbuf(.4)
    place(out, scrape(r, .05, 1500, 6000), 0, .5); place(out, clack(r, 520, .07), .05, 1.0)
    place(out, clink(1700 * j, .25), .06, .35); place(out, tick(r, 2900), .1, .4)
    return out

def shotgun_empty(r, p, i):
    out = newbuf(.2)
    place(out, clack(r, 420, .06), 0, .8); place(out, tick(r, 2200, .04), 0, .5)
    return out

def shotgun_casing(r, p, i):                        # vỏ nhựa + đầu đồng
    out = casing(r, 1200 * p, .7, 3, 35)
    place(out, casing(r, 3200 * p, .7, 3, 60), 0, .3)
    return out


# ============================================================ 4. LỰU ĐẠN: rút chốt, ném, nảy, nổ
def grenade_pin(r, p, i):
    out = newbuf(.7)
    place(out, tick(r, 3200, .03), 0, .9); place(out, clink(2600 * p, .6), 0, .35)
    place(out, clink(4700 * p, .5), .14, .3); place(out, clack(r, 900, .05), .14, .5)   # tay gạt bật ra
    return out

def grenade_throw(r, p, i):
    d = .5
    return whoosh(d, 300, 3500, r) * .9 + .5 * lp(noise(d, r), 500) * np.sin(np.pi * tt(d) / d) ** 2

def grenade_bounce(r, p, i):
    base = (260, 340, 290)[i % 3] * p
    out = newbuf(.55)
    place(out, clink(base, .5), 0, .6); place(out, burst(.06, 200, 3500, r, decay=70), 0, .9)
    place(out, thud(.15, 150, 70, 30, .3, r), 0, .8)
    return out

def grenade_explode(r, p, i):
    return explosion(r, 3.2, (95 * p, 28), 2.0, 1.4, 40, .4, 1.8)


# ============================================================ 5. ROCKET: nạp, phóng, bay (lặp), nổ lớn
def rocket_load(r, p, i):
    out = newbuf(.9)
    place(out, clack(r, 300, .12), 0, 1.2); place(out, thud(.2, 120, 50, 25, .3, r), 0, .8)
    place(out, tick(r, 2400), .25, .6); place(out, tick(r, 2900), .42, .6)              # khóa chốt
    place(out, clack(r, 500, .08), .55, .9)
    return out

def rocket_fire(r, p, i):
    d = 1.8
    out = newbuf(d)
    place(out, thud(.5, 80, 30, 6, .3, r), 0, 1.3)                                     # bụp đánh lửa
    place(out, burst(.15, 300, 6000, r, decay=25, attack=.002), 0, 1.0)
    place(out, lp(noise(d, r), 1800) * curve(d, [(0, 0), (.06, 1), (.6, .8), (d, 0)])
          * (.8 + .2 * np.clip(smooth_noise(d, 60, r), -2, 2) / 2), .02, 1.0)          # tiếng gầm phụt lửa
    place(out, bp(noise(d, r), 3000, 10000) * curve(d, [(0, 0), (.1, .6), (1.0, .3), (d, 0)]), .02, .3)
    place(out, lp(noise(d, r), 200) * np.exp(-tt(d) * 1.5), 0, 1.0)
    return np.tanh(reverb(out, 1.2, .4, r) * 1.1)

def rocket_flight(r, p, i):                         # lặp liền mạch (crossfade đầu-cuối)
    L, f, d = n_of(1.5), n_of(.25), 1.75
    x = (lp(noise(d, r), 1600) * (.75 + .25 * np.clip(smooth_noise(d, 70, r), -2, 2) / 2)
         + .9 * lp(noise(d, r), 150) + .18 * bp(noise(d, r), 2500, 9000))
    y = x[:L].copy()
    w = np.linspace(0, np.pi / 2, f)
    y[:f] = x[:f] * np.sin(w) + x[L:L + f] * np.cos(w)
    return y

def rocket_explode(r, p, i):
    return explosion(r, 4.0, (75 * p, 20), 1.5, 1.0, 60, 1.0, 2.4)


# ============================================================ 6. RAILGUN: sạc điện, nổ điện từ, xả nhiệt
def railgun_charge(r, p, i):
    d = 1.3
    t = tt(d)
    f = (160 + (2600 - 160) * (t / d) ** 2.2) * p * (1 + .015 * np.sin(2 * np.pi * 35 * t))
    ph = np.cumsum(f) / SR
    w = np.sin(2 * np.pi * ph) + .5 * np.sin(4 * np.pi * ph) + .25 * np.sin(6 * np.pi * ph)
    hum = lp(2 * ((np.arange(len(t)) * 55 / SR) % 1) - 1, 400) * .4 * curve(d, [(0, .3), (d, 1)])
    out = w * curve(d, [(0, 0), (.15, .3), (d - .05, 1), (d, .9)]) + hum
    out += .5 * crackles(d, 200, 1500, 7000, r) * curve(d, [(0, 0), (d, 1)])
    place(out, tick(r, 3500, .03), d - .06, .6)                                        # báo sẵn sàng
    return out

def railgun_fire(r, p, i):
    d = 1.4
    j = r.uniform(.9, 1.1)
    out = newbuf(d)
    place(out, burst(.012, 2000, 16000, r, decay=600, attack=.0002), 0, 1.5)           # tia điện
    place(out, sweep(.25, 7000 * p * j, 180, "saw") * np.exp(-tt(.25) * 9), 0, .9)     # "pew" trượt tần
    place(out, thud(d, 110, 32, 4.5, 0, r), 0, 1.6)                                   # sóng xung kích
    rt = tt(.9)
    place(out, sum(np.sin(2 * np.pi * f * j * rt) * np.exp(-rt * dc)
                   for f, dc in ((2300, 7), (3700, 9), (5200, 12))), 0, .3)            # nòng ngân kim loại
    place(out, crackles(.8, 140, 1500, 8000, r, 4), .02, .6)                           # tia lửa điện
    place(out, burst(.25, 200, 3000, r, decay=16, attack=.001), 0, .9)
    return np.tanh(reverb(out, .9, .45, r, 6000) * 1.2)

def railgun_cooldown(r, p, i):
    d = 1.7
    out = newbuf(d)
    place(out, bp(noise(d, r), 3500, 11000) * curve(d, [(0, 0), (.04, 1), (.5, .7), (d, 0)]), 0, .7)   # xả hơi
    place(out, sweep(1.5, 1900, 140) * curve(1.5, [(0, 0), (.05, 1), (1.5, 0)]), 0, .18)
    for _ in range(7):                                                                  # kim loại nguội co lại
        place(out, tick(r, r.uniform(2000, 4000), .03), r.uniform(.35, 1.6), .25)
    return out

def railgun_empty(r, p, i):                         # cảnh báo quá nhiệt: bíp bíp
    out = newbuf(.4)
    for k in range(2):
        s = np.sign(np.sin(2 * np.pi * 240 * p * tt(.09))) * curve(.09, [(0, 0), (.005, 1), (.08, 1), (.09, 0)])
        place(out, lp(s, 2500), k * .14, .5)
    place(out, tick(r, 2600, .03), 0, .4)
    return out

def railgun_impact(r, p, i):                        # đạn xuyên trúng mục tiêu
    d = .55
    out = newbuf(d)
    place(out, crackles(d, 350, 800, 7000, r, 6), 0, .9)
    place(out, sweep(.14, 3500 * p, 350, "saw") * np.exp(-tt(.14) * 14), 0, .6)
    place(out, thud(.25, 150, 60, 20, .4, r), 0, .9)
    place(out, burst(.1, 1000, 9000, r, decay=40), 0, .8)
    return out


# ------------------------------------------------------------ xuất file
WEAPONS = {
    "pistol":  {"fire": 3, "reload": 1, "empty": 1, "casing": 2},
    "uzi":     {"fire": 4, "reload": 1, "empty": 1, "casing": 2},
    "shotgun": {"fire": 3, "pump": 2, "load": 2, "empty": 1, "casing": 2},
    "grenade": {"pin": 1, "throw": 1, "bounce": 3, "explode": 2},
    "rocket":  {"load": 1, "fire": 2, "flight": 1, "explode": 2},
    "railgun": {"charge": 1, "fire": 3, "cooldown": 1, "empty": 1, "impact": 2},
}
VOLUME = {"fire": 1.0, "explode": 1.0, "reload": .6, "empty": .5, "casing": .35, "pump": .75, "load": .6,
          "pin": .6, "throw": .7, "bounce": .7, "flight": .55, "charge": .8, "cooldown": .6, "impact": .8}
LOOPS = {("rocket", "flight")}
REELS = {   # nghe thử: (sự kiện, biến thể, thời điểm giây)
    "pistol": [("fire", 0, 0), ("casing", 0, .35), ("fire", 1, .9), ("casing", 1, 1.25), ("fire", 2, 1.8),
               ("casing", 0, 2.15), ("empty", 0, 2.9), ("reload", 0, 3.5)],
    "uzi": [("fire", k % 4, .075 * k) for k in range(12)] +
           [("casing", 0, .5), ("casing", 1, .7), ("casing", 0, .95), ("empty", 0, 1.5), ("reload", 0, 2.2)],
    "shotgun": [("fire", 0, 0), ("pump", 0, .9), ("casing", 0, 1.2), ("fire", 1, 2.2), ("pump", 1, 3.1),
                ("casing", 1, 3.4), ("load", 0, 4.2), ("load", 1, 4.65), ("pump", 0, 5.2), ("fire", 2, 6.2),
                ("empty", 0, 7.8)],
    "grenade": [("pin", 0, 0), ("throw", 0, .6), ("bounce", 0, 1.4), ("bounce", 1, 1.8), ("bounce", 2, 2.1),
                ("explode", 0, 2.7), ("explode", 1, 6.5)],
    "rocket": [("load", 0, 0), ("fire", 0, 1.0), ("flight", 0, 1.1), ("flight", 0, 2.6), ("explode", 0, 4.1),
               ("fire", 1, 8.5), ("flight", 0, 8.6), ("explode", 1, 10.0)],
    "railgun": [("charge", 0, 0), ("fire", 0, 1.3), ("cooldown", 0, 2.6), ("charge", 0, 4.6), ("fire", 1, 5.9),
                ("impact", 0, 6.2), ("impact", 1, 6.6), ("cooldown", 0, 7.5), ("empty", 0, 9.5), ("fire", 2, 10.2)],
}


def finish(x, peak=.9, loop=False):
    x = x - np.mean(x)
    x = np.tanh(x / (np.percentile(np.abs(x), 99.7) + 1e-9) * 1.2)       # nén đỉnh nhọn cho "đã" tai
    x = x / (np.max(np.abs(x)) + 1e-9) * peak
    if not loop:
        fi, fo = int(SR * .001), int(SR * .03)
        x[:fi] *= np.linspace(0, 1, fi)
        x[-fo:] *= np.linspace(1, 0, fo)
    return x.astype(np.float32)


def save(path, x):
    with wave.open(path, "wb") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR)
        w.writeframes((np.clip(x, -1, 1) * 32767).astype("<i2").tobytes())


if __name__ == "__main__":
    sounds, manifest, stats = {}, {}, []
    for wp, events in WEAPONS.items():
        os.makedirs(f"{OUT_DIR}/weapons/{wp}", exist_ok=True)
        sounds[wp], manifest[wp] = {}, {}
        for ev, count in events.items():
            sounds[wp][ev], manifest[wp][ev] = [], []
            for i in range(count):
                r = np.random.default_rng(zlib.crc32(f"{wp}/{ev}/{i}".encode()))
                x = finish(globals()[f"{wp}_{ev}"](r, r.uniform(.97, 1.03), i), loop=(wp, ev) in LOOPS)
                rel = f"weapons/{wp}/{ev}_{i + 1}.wav"
                save(f"{OUT_DIR}/{rel}", x)
                sounds[wp][ev].append(x)
                manifest[wp][ev].append(rel)
                stats.append((wp, ev, i + 1, len(x) / SR, float(np.max(np.abs(x))), float(np.sqrt(np.mean(x ** 2))),
                              bool(np.isfinite(x).all())))

    for wp, line in REELS.items():                  # bản demo nghe thử từng vũ khí
        end = max(t + len(sounds[wp][ev][i]) / SR for ev, i, t in line) + .4
        reel = newbuf(end)
        for ev, i, t in line:
            place(reel, sounds[wp][ev][i], t, VOLUME[ev])
        save(f"{OUT_DIR}/audio_demo_weapon_{wp}.wav", finish(reel, .9))

    json.dump({"sample_rate": SR, "format": "wav mono 16-bit", "volume": VOLUME,
               "loop": [f"{a}/{b}" for a, b in LOOPS], "sounds": manifest},
              open(f"{OUT_DIR}/weapon_audio_manifest.json", "w"), indent=2)
    with zipfile.ZipFile(f"{OUT_DIR}/weapon_audio.zip", "w", zipfile.ZIP_DEFLATED) as z:
        for wp in WEAPONS:
            for ev in WEAPONS[wp]:
                for rel in manifest[wp][ev]:
                    z.write(f"{OUT_DIR}/{rel}", rel)
        z.write(f"{OUT_DIR}/weapon_audio_manifest.json", "weapon_audio_manifest.json")

    print(f"{'weapon':8} {'event':8} n  dur   peak  rms   ok")
    for s in stats:
        print(f"{s[0]:8} {s[1]:8} {s[2]}  {s[3]:.2f}s {s[4]:.2f}  {s[5]:.3f} {s[6]}")

    try:                                            # ảnh phổ âm để kiểm tra bằng mắt
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        fig, axs = plt.subplots(len(WEAPONS), 6, figsize=(20, 11))
        for a, wp in enumerate(WEAPONS):
            for b in range(6):
                ax = axs[a][b]
                if b >= len(WEAPONS[wp]):
                    ax.axis("off")
                    continue
                ev = list(WEAPONS[wp])[b]
                ax.specgram(sounds[wp][ev][0], NFFT=1024, Fs=SR, noverlap=768, cmap="magma")
                ax.set_ylim(0, 12000)
                ax.set_title(f"{wp} / {ev}", fontsize=8)
                ax.tick_params(labelsize=6)
        fig.tight_layout()
        fig.savefig(f"{OUT_DIR}/weapon_audio_overview.png", dpi=70)
    except Exception as e:
        print("bỏ qua ảnh phổ:", e)
